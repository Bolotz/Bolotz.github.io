Title: -Team 8- 
Tags: TCMG, A&M
Date: 2021-01-23
Modified: 2021-01-25
Category: -Home-
Authors: Juan Quiroz, Zachary Bolton, Nathan Romano, William Brooks
Summary: Welcome to our new website built for TCMG 412!

<html>
    <head>
        <title>-Team 8-</title>
        <meta name="tags" content="TCMG, A&M" />
        <meta name="date" content="2021-01-23" />
        <meta name="modified" content="2021-01-25" />
        <meta name="category" content="-Home-" />
        <meta name="authors" content="Juan Quiroz, Zachary Bolton, Nathan Romano, William Brooks" />
        <meta name="summary" content="Welcome to our new website built for TCMG 412!" />
    </head>
    <body>
        <center><img src="images/logo.jpg" alt="Texas A&M Logo" width="200" height="200">
        <p>Welcome to our webpage! Our team consists of four people. This website was designed for a lab project that we indivually had to create and deploy. We split our team into two subgroups, one group consisting of Devs and the other of Ops.</p>
        <img src="images/campus.jpg" alt="Texas A&M Campus" width="700"height="400"></center>
    </body>
</html>
