Title: A&M Trivia
Tags: Aggies, Education
Date: 2021-01-23
Modified: 2021-01-25
Category: College
Authors: Juan Quiroz, Zachary Bolton, Nathan Romano, William Brooks
Summary: Interesting facts about A&M

<html>
    <head>
        <title>A&M Trivia</title>
        <meta name="tags" content="Aggies, Education" />
        <meta name="date" content="2021-01-23" />
        <meta name="modified" content="2021-01-25" />
        <meta name="category" content="College" />
        <meta name="authors" content="Juan Quiroz, Zachary Bolton, Nathan Romano, William Brooks" />
        <meta name="summary" content="Interesting facts about A&M" />
    </head>
    <body>
        <p>Texas A&M was founded in 1876, and we are now the second biggest student body in the US!
            We are also the only college in Texas to hold land, sea, and space grant status.
            Our main campus is 5200 acres, but only a fifth of students live on campus.</p>
        <center><img src="images/dog.jpg" alt="Reveille" width="700" height="525">
        <img src="images/man.jpg" alt="The 12th Man" width="600"height="500"></center>
    </body>
</html>
