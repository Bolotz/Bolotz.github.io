Title: Our Pets
Tags: Pets, Aww
Date: 2021-01-23
Modified: 2021-01-25
Category: Pets
Authors: Juan Quiroz, Zachary Bolton, Nathan Romano, William Brooks
Summary: Look at our cute pets!

<html>
    <head>
        <title>Our Pets</title>
        <meta name="tags" content="Pets, Aww" />
        <meta name="date" content="2021-01-23" />
        <meta name="modified" content="2021-01-25" />
        <meta name="category" content="Pets" />
        <meta name="authors" content="Juan Quiroz, Zachary Bolton, Nathan Romano, William Brooks" />
        <meta name="summary" content="Look at our cute pets!" />
    </head>
    <body>
        <center><img src="images/Hurley.jpg" alt="My Dog" width="700" height="525">
        <p>Will Brooks speaking here. These are my lovely pets Ravi (cat) and Hurley (dog).</p>
        <img src="images/Ravi.jpg" alt="My Black Cat" width="600"height="800"></center>
    </body>
</html>
